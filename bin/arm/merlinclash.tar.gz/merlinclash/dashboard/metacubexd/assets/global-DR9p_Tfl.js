import{V as a,b2 as m}from"./index-DEvtqFOl.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
